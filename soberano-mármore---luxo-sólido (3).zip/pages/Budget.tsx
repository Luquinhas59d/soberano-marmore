
import React, { useState } from 'react';

const Budget: React.FC = () => {
  const [fileName, setFileName] = useState<string>('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFileName(e.target.files[0].name);
    }
  };

  const handleWhatsAppRedirect = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget as HTMLFormElement);
    const name = formData.get('name');
    const whatsapp = formData.get('whatsapp');
    const project = formData.get('project');
    const city = formData.get('city');
    const measurements = formData.get('measurements');
    const material = formData.get('material');
    
    let message = `Olá! Meu nome é ${name}. Gostaria de um orçamento para um projeto de ${project} em ${city}.`;
    
    if (material) {
      message += `\n- Material em mente: ${material}`;
    }
    if (measurements) {
      message += `\n- Medidas aproximadas: ${measurements}`;
    }
    if (fileName) {
      message += `\n- Tenho fotos/plantas para enviar.`;
    }
    
    const whatsappUrl = `https://wa.me/5511968143372?text=${encodeURIComponent(message)}`;
    
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="pt-40 pb-32 bg-[#0F172A] min-h-screen animate-in fade-in duration-700">
      <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        
        {/* Lado Esquerdo: Conteúdo Informativo */}
        <div className="animate-in slide-in-from-left duration-1000">
          <span className="text-[#D4AF37] tracking-[0.4em] text-[10px] font-bold mb-6 block uppercase">INVESTIMENTO INTELIGENTE</span>
          <h1 className="text-white text-5xl md:text-7xl font-serif mb-10 leading-[1.1]">
            Vamos dar forma ao seu <span className="text-[#D4AF37] italic">sonho</span>?
          </h1>
          <p className="text-slate-400 mb-14 max-w-lg leading-relaxed text-lg font-light">
            Preencha os detalhes abaixo para iniciar seu orçamento personalizado. Nossa equipe de especialistas está pronta para transformar seu ambiente com a nobreza das pedras.
          </p>
          
          <div className="space-y-10">
            <div className="flex items-center space-x-6 group">
              <div className="w-14 h-14 rounded-full border border-white/10 flex items-center justify-center text-white font-serif text-xl group-hover:border-[#D4AF37] transition-colors">
                01
              </div>
              <div>
                <h4 className="text-white font-bold text-lg">Atendimento Imediato</h4>
                <p className="text-slate-500 text-sm">Conecte-se diretamente com nossos especialistas via WhatsApp.</p>
              </div>
            </div>
            <div className="flex items-center space-x-6 group">
              <div className="w-14 h-14 rounded-full border border-white/10 flex items-center justify-center text-white font-serif text-xl group-hover:border-[#D4AF37] transition-colors">
                02
              </div>
              <div>
                <h4 className="text-white font-bold text-lg">Orçamento Dinâmico</h4>
                <p className="text-slate-500 text-sm">Receba estimativas precisas baseadas nos detalhes do seu projeto.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Lado Direito: Formulário com Borda Glow Azul (Conceito Luxo Sólido) */}
        <div className="relative p-[2px] rounded-[40px] bg-gradient-to-br from-blue-500/40 via-blue-400/10 to-transparent shadow-[0_0_50px_rgba(59,130,246,0.15)] animate-in slide-in-from-right duration-1000">
          <div className="bg-[#131C31] p-8 md:p-14 rounded-[38px] border border-white/5 backdrop-blur-3xl">
            <form onSubmit={handleWhatsAppRedirect} className="space-y-8">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-slate-500 text-[10px] tracking-[0.3em] font-bold mb-3 uppercase">NOME</label>
                  <input 
                    name="name" 
                    required 
                    type="text" 
                    placeholder="Seu nome"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-blue-400/50 transition-all" 
                  />
                </div>
                <div>
                  <label className="block text-slate-500 text-[10px] tracking-[0.3em] font-bold mb-3 uppercase">WHATSAPP</label>
                  <input 
                    name="whatsapp"
                    required 
                    type="tel" 
                    placeholder="(00) 00000-0000"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-blue-400/50 transition-all" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-slate-500 text-[10px] tracking-[0.3em] font-bold mb-3 uppercase">TIPO DE PROJETO</label>
                  <select name="project" className="w-full bg-[#131C31] border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-blue-400/50 transition-all appearance-none cursor-pointer">
                    <option>Cozinha</option>
                    <option>Banheiro</option>
                    <option>Escada</option>
                    <option>Área Gourmet</option>
                    <option>Comercial</option>
                    <option>Outro</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 text-[10px] tracking-[0.3em] font-bold mb-3 uppercase">CIDADE</label>
                  <select name="city" className="w-full bg-[#131C31] border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-blue-400/50 transition-all appearance-none cursor-pointer">
                    <option>Salto</option>
                    <option>Itu</option>
                    <option>Indaiatuba</option>
                    <option>Sorocaba</option>
                    <option>Outra</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-slate-500 text-[10px] tracking-[0.3em] font-bold mb-3 uppercase">MEDIDAS (OPCIONAL)</label>
                  <input 
                    name="measurements" 
                    type="text" 
                    placeholder="Ex: 2.50m x 0.60m"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-blue-400/50 transition-all" 
                  />
                </div>
                <div>
                  <label className="block text-slate-500 text-[10px] tracking-[0.3em] font-bold mb-3 uppercase">MATERIAL EM MENTE</label>
                  <input 
                    name="material" 
                    type="text" 
                    placeholder="Ex: Quartzito Taj Mahal"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-blue-400/50 transition-all" 
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 text-[10px] tracking-[0.3em] font-bold mb-3 uppercase">ANEXAR FOTO OU PLANTA</label>
                <div className="relative group">
                  <input 
                    type="file" 
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" 
                    accept="image/*,.pdf"
                  />
                  <div className="w-full bg-white/5 border border-dashed border-white/20 group-hover:border-blue-400/50 rounded-2xl px-6 py-5 text-slate-400 text-sm flex items-center justify-between transition-all">
                    <div className="flex items-center space-x-4">
                      <i className="fas fa-camera text-blue-400/50 text-lg"></i>
                      <span className="truncate">{fileName || 'Selecione fotos do local ou planta'}</span>
                    </div>
                    <i className="fas fa-plus-circle text-blue-400/30"></i>
                  </div>
                </div>
              </div>

              <button type="submit" className="w-full bg-blue-600/20 border border-blue-400/40 text-white py-6 font-bold tracking-[0.3em] text-[11px] rounded-2xl hover:bg-blue-500 hover:text-white transition-all shadow-[0_15px_30px_rgba(59,130,246,0.1)] flex items-center justify-center space-x-4 group mt-4">
                <i className="fab fa-whatsapp text-xl text-blue-400 group-hover:text-white"></i>
                <span>SOLICITAR ORÇAMENTO</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Budget;
