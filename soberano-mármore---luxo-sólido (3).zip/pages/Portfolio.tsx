
import React from 'react';
import { PROJECTS } from '../constants';

const Portfolio: React.FC = () => {
  const handleImgError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    e.currentTarget.src = "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format,compress&fit=crop&w=1200&q=70";
  };

  return (
    <div className="pt-40 pb-32 bg-midnight min-h-screen animate-in fade-in duration-700">
      <div className="container mx-auto px-6">
        <header className="mb-24 text-center max-w-4xl mx-auto">
          <span className="text-gold tracking-[0.5em] text-[10px] font-bold mb-6 block uppercase">Execução de Excelência</span>
          <h1 className="text-white text-6xl md:text-8xl font-serif mb-8 leading-none">Obras que Inspiram</h1>
          <p className="text-slate-400 text-lg md:text-xl font-light leading-relaxed">
            Nossa trajetória é marcada por projetos que desafiam o comum e celebram a beleza eterna das pedras naturais e tecnológicas.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 lg:gap-24">
          {PROJECTS.map((project, idx) => (
            <div 
              key={project.id} 
              className={`group flex flex-col ${idx % 2 !== 0 ? 'md:mt-32' : ''}`}
            >
              <div className="relative overflow-hidden aspect-[4/5] bg-slate-900 rounded-lg shadow-2xl">
                <img 
                  src={`${project.image.split('?')[0]}?auto=format,compress&fit=crop&w=1200&q=70`} 
                  alt={project.title} 
                  onError={handleImgError}
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover transition-transform duration-[3s] group-hover:scale-110 opacity-70 group-hover:opacity-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-midnight/80 via-transparent to-transparent opacity-60"></div>
                
                {/* Floating Badge */}
                <div className="absolute top-8 right-8">
                  <span className="bg-white/5 backdrop-blur-md border border-white/10 text-white text-[9px] font-bold tracking-[0.2em] px-5 py-2 rounded-full uppercase">
                    {project.category}
                  </span>
                </div>
              </div>
              
              <div className="mt-12 group">
                <p className="text-gold text-[10px] tracking-[0.4em] font-bold mb-4 uppercase">{project.location}</p>
                <h3 className="text-white text-3xl font-serif mb-6 group-hover:text-gold transition-colors duration-500">{project.title}</h3>
                <div className="w-12 h-[1px] bg-gold/50 group-hover:w-full transition-all duration-700"></div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-40 pt-20 border-t border-white/5 text-center">
          <h2 className="text-white text-3xl font-serif mb-12">Pronto para ser o próximo caso de sucesso?</h2>
          <button 
            onClick={() => window.location.href = '#budget'}
            className="bg-transparent border border-gold text-gold hover:bg-gold hover:text-[#0F172A] px-16 py-6 font-bold tracking-[0.3em] transition-all text-[10px]"
          >
            SOLICITAR ORÇAMENTO
          </button>
        </div>
      </div>
    </div>
  );
};

export default Portfolio;
