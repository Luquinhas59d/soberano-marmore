
import React from 'react';

const Location: React.FC = () => {
  return (
    <div className="bg-[#0F172A] min-h-screen animate-in fade-in duration-1000">
      {/* Hero Header */}
      <section className="pt-48 pb-20 container mx-auto px-6 text-center">
        <span className="text-[#D4AF37] tracking-[0.6em] text-[10px] font-bold mb-6 block uppercase">Onde a Arte Ganha Forma</span>
        <h1 className="text-white text-5xl md:text-7xl font-serif mb-8">Atendimento em <span className="text-[#D4AF37] italic">Salto e Região</span></h1>
        <p className="text-slate-400 text-lg md:text-xl font-light max-w-2xl mx-auto leading-relaxed">
          Nossa sede estratégica em São Paulo atende com agilidade e precisão técnica projetos em Salto, Itu, Indaiatuba e toda a capital.
        </p>
      </section>

      {/* Map & Info Section */}
      <section className="py-20 container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-stretch">
          
          {/* Contact Cards */}
          <div className="lg:col-span-1 space-y-6">
            <div className="glass p-10 rounded-[40px] border-white/10 hover:border-[#D4AF37]/30 transition-all group">
              <div className="w-12 h-12 bg-[#D4AF37]/10 rounded-2xl flex items-center justify-center mb-6 border border-[#D4AF37]/20 group-hover:bg-[#D4AF37] transition-all">
                <i className="fas fa-map-marked-alt text-[#D4AF37] group-hover:text-midnight"></i>
              </div>
              <h3 className="text-white text-xl font-serif mb-4">Showroom & Sede</h3>
              <p className="text-slate-400 font-light leading-relaxed">
                Rua Major Lúcio Dias Ramos, 270<br/>
                Jardim Belcito - São Paulo/SP<br/>
                Atendendo: Salto, Itu e Indaiatuba
              </p>
            </div>

            <div className="glass p-10 rounded-[40px] border-white/10 hover:border-[#D4AF37]/30 transition-all group">
              <div className="w-12 h-12 bg-[#D4AF37]/10 rounded-2xl flex items-center justify-center mb-6 border border-[#D4AF37]/20 group-hover:bg-[#D4AF37] transition-all">
                <i className="fas fa-phone-alt text-[#D4AF37] group-hover:text-midnight"></i>
              </div>
              <h3 className="text-white text-xl font-serif mb-4">Contato Comercial</h3>
              <p className="text-slate-400 font-light">Agende uma visita técnica ou reunião em sua obra.</p>
              <p className="text-[#D4AF37] font-bold mt-4">(11) 96814-3372</p>
            </div>

            <button 
              onClick={() => window.open('https://www.google.com/maps/search/?api=1&query=Rua+Major+Lúcio+Dias+Ramos+270+Jardim+Belcito+São+Paulo', '_blank')}
              className="w-full bg-[#D4AF37] text-midnight py-6 rounded-full font-bold tracking-[0.3em] text-[10px] hover:bg-white transition-all transform hover:-translate-y-1 shadow-lg shadow-[#D4AF37]/10 flex items-center justify-center space-x-3"
            >
              <i className="fas fa-location-arrow"></i>
              <span>ABRIR NO GOOGLE MAPS</span>
            </button>
          </div>

          {/* Interactive Map */}
          <div className="lg:col-span-2 relative min-h-[500px] rounded-[40px] overflow-hidden border border-white/5 shadow-2xl">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.9254316374095!2d-46.7024345!3d-23.7441548!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce499999999999%3A0x7d9f67a2d3c9f7a!2sR.%20Maj.%20L%C3%BAcio%20Dias%20Ramos%2C%20270%20-%20Jardim%20Belcito%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004855-330!5e0!3m2!1spt-BR!2sbr!4v1700000000000!5m2!1spt-BR!2sbr" 
              className="absolute inset-0 w-full h-full border-0 grayscale invert contrast-75 opacity-70"
              allowFullScreen={true}
              loading="lazy" 
            ></iframe>
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-midnight via-transparent to-transparent"></div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Location;
