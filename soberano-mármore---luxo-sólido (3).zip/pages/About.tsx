
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="bg-[#0F172A] min-h-screen animate-in fade-in duration-1000">
      {/* 1. O Cabeçalho (A primeira impressão) */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <img 
          src="https://i.postimg.cc/zfsH71Dd/workshop.jpg" 
          className="absolute inset-0 w-full h-full object-cover opacity-30 scale-110 animate-subtle-zoom" 
          alt="Ambiente de Luxo Soberano"
          loading="lazy"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0F172A]/90 via-transparent to-[#0F172A]"></div>
        <div className="relative z-10 text-center px-6 max-w-5xl">
          <span className="text-[#D4AF37] tracking-[0.6em] text-xs font-bold mb-8 block uppercase animate-in slide-in-from-top duration-1000">
            Tradição & Vanguarda
          </span>
          <h1 className="text-white text-5xl md:text-7xl lg:text-8xl font-serif leading-tight mb-8 animate-in slide-in-from-bottom duration-1000 delay-200">
            Soberano Mármore: A Arte de <br className="hidden md:block"/>
            <span className="text-[#D4AF37] italic">Materializar a Sofisticação</span>
          </h1>
          <p className="text-slate-300 text-lg md:text-2xl font-light tracking-wide max-w-3xl mx-auto border-t border-white/10 pt-8 animate-in fade-in duration-1000 delay-500">
            Há mais de uma década definindo o alto padrão em rochas naturais e superfícies nobres em Salto e região.
          </p>
        </div>
      </section>

      {/* 2. O Texto Principal (A História) */}
      <section className="py-32 container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <div className="relative order-2 lg:order-1">
            <div className="absolute -top-12 -left-12 w-64 h-64 border border-[#D4AF37]/20 rounded-full blur-3xl"></div>
            <h2 className="text-[#D4AF37] text-4xl md:text-5xl font-serif mb-12">Nossa História</h2>
            <div className="space-y-8 text-slate-300 font-light leading-relaxed text-lg">
              <p className="text-xl text-white font-medium">
                Muito mais do que uma marmoraria, a Soberano Mármore é um ateliê de rochas.
              </p>
              <p>
                Com mais de 10 anos de história em Salto, nascemos com um propósito inegociável: elevar o nível de acabamento da construção civil. Entendemos que quem busca mármore, não busca apenas uma pedra fria; busca a exclusividade, a perenidade e a beleza que só os materiais nobres podem oferecer.
              </p>
              <p>
                Ao longo desta década, nos especializamos em atender projetos que exigem rigor técnico e sensibilidade estética. Da escolha da chapa perfeita na pedreira até o assentamento milimétrico na sua obra, nossa equipe é treinada para garantir que o resultado final seja, no mínimo, impecável.
              </p>
              <p>
                Unimos a tradição do trabalho artesanal com a tecnologia de corte moderna para entregar bancadas, pisos, escadas e revestimentos que valorizam o seu imóvel e respeitam o seu investimento.
              </p>
            </div>
          </div>
          <div className="relative group order-1 lg:order-2">
            <div className="absolute inset-0 border-2 border-[#D4AF37] translate-x-6 translate-y-6 rounded-[40px] transition-transform group-hover:translate-x-4 group-hover:translate-y-4"></div>
            <div className="relative z-10 rounded-[40px] overflow-hidden shadow-2xl aspect-square lg:aspect-auto lg:h-[700px]">
              <img 
                src="https://i.postimg.cc/zfsH71Dd/workshop.jpg" 
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000 scale-105 group-hover:scale-100" 
                alt="Processo de produção Soberano"
                loading="lazy"
                decoding="async"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 3. Os Diferenciais (Por que escolher vocês?) */}
      <section className="py-32 bg-white/[0.02] border-y border-white/5 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] border border-[#D4AF37] rounded-full"></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-24">
            <span className="text-[#D4AF37] tracking-[0.4em] text-[10px] font-bold mb-4 block uppercase">Excelência em cada etapa</span>
            <h2 className="text-white text-4xl md:text-5xl font-serif">Por que a Soberano é a escolha <br className="hidden md:block"/> certa para o seu projeto?</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Diferencial 1 */}
            <div className="glass p-10 rounded-[40px] border-white/10 group hover:border-[#D4AF37]/40 transition-all duration-500 hover:-translate-y-2">
              <div className="w-14 h-14 bg-[#D4AF37]/10 rounded-2xl flex items-center justify-center mb-8 border border-[#D4AF37]/20 group-hover:bg-[#D4AF37] transition-all">
                <i className="fas fa-gem text-[#D4AF37] text-xl group-hover:text-[#0F172A] transition-all"></i>
              </div>
              <h3 className="text-white text-xl font-serif mb-4">Curadoria Exclusiva</h3>
              <p className="text-slate-400 font-light leading-relaxed text-sm">
                Trabalhamos com uma seleção rigorosa de mármores, granitos, quartzitos e superfícies sintéticas (quartzo/lâminas) das melhores procedências mundiais.
              </p>
            </div>

            {/* Diferencial 2 */}
            <div className="glass p-10 rounded-[40px] border-white/10 group hover:border-[#D4AF37]/40 transition-all duration-500 hover:-translate-y-2">
              <div className="w-14 h-14 bg-[#D4AF37]/10 rounded-2xl flex items-center justify-center mb-8 border border-[#D4AF37]/20 group-hover:bg-[#D4AF37] transition-all">
                <i className="fas fa-microscope text-[#D4AF37] text-xl group-hover:text-[#0F172A] transition-all"></i>
              </div>
              <h3 className="text-white text-xl font-serif mb-4">Alta Precisão</h3>
              <p className="text-slate-400 font-light leading-relaxed text-sm">
                Nossa assinatura é o detalhe. Cortes em 45º perfeitos, emendas imperceptíveis e polimento espelhado com tecnologia de ponta.
              </p>
            </div>

            {/* Diferencial 3 */}
            <div className="glass p-10 rounded-[40px] border-white/10 group hover:border-[#D4AF37]/40 transition-all duration-500 hover:-translate-y-2">
              <div className="w-14 h-14 bg-[#D4AF37]/10 rounded-2xl flex items-center justify-center mb-8 border border-[#D4AF37]/20 group-hover:bg-[#D4AF37] transition-all">
                <i className="fas fa-comments text-[#D4AF37] text-xl group-hover:text-[#0F172A] transition-all"></i>
              </div>
              <h3 className="text-white text-xl font-serif mb-4">Consultoria Especializada</h3>
              <p className="text-slate-400 font-light leading-relaxed text-sm">
                Não apenas vendemos; orientamos a melhor pedra para cada tipo de uso (cozinha, banho, gourmet), garantindo durabilidade máxima e estética.
              </p>
            </div>

            {/* Diferencial 4 */}
            <div className="glass p-10 rounded-[40px] border-white/10 group hover:border-[#D4AF37]/40 transition-all duration-500 hover:-translate-y-2">
              <div className="w-14 h-14 bg-[#D4AF37]/10 rounded-2xl flex items-center justify-center mb-8 border border-[#D4AF37]/20 group-hover:bg-[#D4AF37] transition-all">
                <i className="fas fa-map-marker-alt text-[#D4AF37] text-xl group-hover:text-[#0F172A] transition-all"></i>
              </div>
              <h3 className="text-white text-xl font-serif mb-4">Tradição em Salto</h3>
              <p className="text-slate-400 font-light leading-relaxed text-sm">
                Uma empresa sólida, com sede própria e mais de 10 anos de compromisso real com prazos e excelência nas regiões de Salto, Itu e Indaiatuba.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Chamada para Ação (CTA) */}
      <section className="py-40 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gold/5 blur-[150px] rounded-full scale-150 -z-10"></div>
        <div className="container mx-auto px-6 max-w-4xl">
          <h2 className="text-white text-4xl md:text-6xl font-serif mb-8">Seu projeto merece a <br/> <span className="text-[#D4AF37] italic">assinatura Soberano</span>.</h2>
          <p className="text-slate-400 text-lg md:text-xl font-light mb-16 max-w-2xl mx-auto">
            Não arrisque o acabamento dos seus sonhos. Converse com nossos especialistas e descubra como podemos transformar seu ambiente.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <button 
              onClick={() => window.location.href = '#budget'}
              className="w-full sm:w-auto bg-[#D4AF37] text-[#0F172A] px-16 py-6 rounded-full font-bold tracking-[0.3em] hover:bg-white transition-all transform hover:-translate-y-1 shadow-[0_20px_40px_rgba(212,175,55,0.3)] text-xs"
            >
              SOLICITAR ORÇAMENTO
            </button>
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <button 
                onClick={() => window.open('https://wa.me/5511968143372', '_blank')}
                className="w-full sm:w-auto border border-white/20 text-white px-12 py-6 rounded-full font-bold tracking-[0.3em] hover:bg-white hover:text-[#0F172A] transition-all text-xs flex items-center justify-center space-x-3"
              >
                <i className="fab fa-whatsapp"></i>
                <span>WHATSAPP</span>
              </button>
              <button 
                onClick={() => window.open('https://www.instagram.com/soberano_marmoresegranitos?igsh=a2Z0aDFpbjEwODRx&utm_source=qr', '_blank')}
                className="w-full sm:w-auto border border-white/20 text-white px-12 py-6 rounded-full font-bold tracking-[0.3em] hover:bg-white hover:text-[#0F172A] transition-all text-xs flex items-center justify-center space-x-3"
              >
                <i className="fab fa-instagram"></i>
                <span>INSTAGRAM</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
