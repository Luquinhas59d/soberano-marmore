
import React, { useState, useEffect } from 'react';

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentPage }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Início', id: 'home' },
    { label: 'Coleções', id: 'catalog' },
    { label: 'Localização', id: 'location' },
    { label: 'Sobre', id: 'about' },
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setIsMenuOpen(false);
  };

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-[#0F172A]/90 backdrop-blur-md py-4 shadow-2xl border-b border-white/5' : 'bg-transparent py-6'}`}>
      <div className="w-full px-4 md:px-10 flex justify-between items-center">
        {/* LOGO - POSICIONADO À ESQUERDA E MAIOR */}
        <div 
          className="flex items-center space-x-6 cursor-pointer group"
          onClick={() => handleNavClick('home')}
        >
          <div className="w-14 h-14 md:w-20 md:h-20 border-2 border-[#D4AF37] flex items-center justify-center transform rotate-45 group-hover:bg-[#D4AF37] transition-all duration-500 shadow-lg shadow-[#D4AF37]/10">
            <i className="fas fa-gem text-[#D4AF37] text-xl md:text-3xl -rotate-45 group-hover:text-[#0F172A] transition-colors"></i>
          </div>
          <div className="flex flex-col">
            <span className="text-white font-serif text-3xl md:text-5xl tracking-[0.2em] leading-none group-hover:text-[#D4AF37] transition-colors">SOBERANO</span>
            <span className="text-[#D4AF37] text-[10px] md:text-xs tracking-[0.6em] font-light mt-2 uppercase">Mármores</span>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center space-x-12">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`text-[10px] font-bold tracking-[0.4em] transition-all relative py-2 overflow-hidden group ${
                currentPage === item.id ? 'text-[#D4AF37]' : 'text-slate-300 hover:text-white'
              }`}
            >
              {item.label.toUpperCase()}
              <span className={`absolute bottom-0 left-0 w-full h-[1px] bg-[#D4AF37] transform transition-transform duration-500 ${currentPage === item.id ? 'translate-x-0' : '-translate-x-full group-hover:translate-x-0'}`}></span>
            </button>
          ))}
          <button 
            onClick={() => handleNavClick('budget')}
            className="bg-[#D4AF37] text-[#0F172A] px-12 py-5 rounded-full text-[10px] font-bold tracking-[0.3em] hover:bg-white transition-all transform hover:scale-105 active:scale-95 shadow-xl shadow-[#D4AF37]/20"
          >
            ORÇAMENTO
          </button>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="lg:hidden text-[#D4AF37] text-2xl z-50 relative w-12 h-12 flex items-center justify-center"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <div className="relative w-8 h-6">
            <span className={`absolute block w-full h-0.5 bg-current transition-all duration-300 ${isMenuOpen ? 'rotate-45 top-3' : 'top-0'}`}></span>
            <span className={`absolute block w-full h-0.5 bg-current transition-all duration-300 top-3 ${isMenuOpen ? 'opacity-0' : 'opacity-100'}`}></span>
            <span className={`absolute block w-full h-0.5 bg-current transition-all duration-300 ${isMenuOpen ? '-rotate-45 top-3' : 'top-6'}`}></span>
          </div>
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <div className={`fixed inset-0 bg-[#0F172A]/98 backdrop-blur-xl z-40 transition-all duration-700 ${isMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
        <div className="flex flex-col items-center justify-center h-full space-y-12">
          {navItems.map((item, index) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              style={{ transitionDelay: isMenuOpen ? `${(index + 1) * 100}ms` : '0ms' }}
              className="text-white text-5xl font-serif tracking-[0.1em] hover:text-[#D4AF37] transition-all transform"
            >
              {item.label}
            </button>
          ))}
          <button 
            onClick={() => handleNavClick('budget')}
            className="bg-[#D4AF37] text-[#0F172A] px-20 py-8 rounded-full font-bold tracking-[0.3em] text-sm"
          >
            ORÇAMENTO
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
